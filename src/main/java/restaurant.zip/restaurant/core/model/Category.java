package restaurant.core.model;

public enum Category {
	STARTER, MAIN_COURSE, DESSERT, DRINK
}